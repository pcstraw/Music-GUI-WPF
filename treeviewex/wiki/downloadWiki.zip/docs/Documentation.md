There is no documentation until now. But look at the samples:

- SimpleSample: Just an instance of a tree bound to a model.
- EditColorsSample: Demonstrates how to edit the color represented by a node by pressing F2. A custom editcontrol is used to achieve this.
- EditSample: Demonstrates how to edit the content of a node by pressing F2.
- EditColorsSample: Some custom edit control.
- BindingSample: Shows how to bind two trees together. 
- VirtualizationSample: Demonstrates the use of virtualization. 