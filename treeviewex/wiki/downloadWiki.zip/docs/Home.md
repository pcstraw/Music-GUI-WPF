**Project Description**
A TreeView which supports, unlike the standard tree in WPF, multiple selection and is a little better stylable.


![](Home_W7StyleSample.jpg)

Selection is can be done by selection rectangle.

![](Home_SelectionRectangle.jpg)

It has also the well known edit functionality.

![](Home_EditTextBox.jpg)