﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace System.Windows.Controls
//{
//    internal class ItemWrapper
//    {
//        public object Data { get; set; }
//        public TreeViewExItem ParentItem { get; set; }
//        public TreeViewExItem Item { get; set; }

//        public int IndexInParent { get; set; }
//    }
//}
